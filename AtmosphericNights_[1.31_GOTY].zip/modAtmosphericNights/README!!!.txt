Install Instructions:

Copy the "bin" folder to your Witcher 3 directory.

That's it.